function f1() {
 "1";
 "2";
}
function f2() {
 "1";
 "2";
}
function f2() {
 if ("1") {
  "1";
 }
 "2";
 if ("3") {
  "4";
 }
}
